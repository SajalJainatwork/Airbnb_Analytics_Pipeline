SELECT * FROM {{ ref('obt') }}  
